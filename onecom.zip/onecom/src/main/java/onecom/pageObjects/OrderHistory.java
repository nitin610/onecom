package onecom.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class OrderHistory extends BasePage{

	private WebDriver driver;
	private By account=By.xpath("//*[@title='View my customer account']");
	private By orderHistor = By.xpath("//*[@title='Orders']");
	private By amount = By.xpath("//*[@class='price']");
	int flag =0;
	
	public OrderHistory(WebDriver driver) {
		super(driver);
		this.driver=driver;
	}
	
	public String order()  {
		
		System.out.println("Order History Summary");
		
		WebElement customerAccount = driver.findElement(account);
		customerAccount.click();

		WebElement orderHistory = driver.findElement(orderHistor);
		orderHistory.click();
	    
		WebElement OrderAmount = driver.findElement(amount);
		
		return OrderAmount.getText();
		
	}
}
