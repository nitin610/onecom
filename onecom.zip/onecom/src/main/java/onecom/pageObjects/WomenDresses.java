package onecom.pageObjects;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class WomenDresses extends BasePage{
	
	private WebDriver driver;
	private By woman=By.xpath("//*[@title='Women']");
	private By chiffonDress = By.xpath("//h5[@itemprop='name']/a[@class='product-name']");
	private By proceedCheckout =  By.xpath("//*[@title='Proceed to checkout']");
	private By cart = By.xpath("//*[@class='shopping_cart']");
	int flag =0;
	
	public WomenDresses(WebDriver driver) {
		super(driver);
		this.driver=driver;
		// TODO Auto-generated constructor stub
	}
	
	public void womanDress() throws Exception {
		
		
		WebElement womanTab = wait.until(
				ExpectedConditions.visibilityOfElementLocated(woman));
		womanTab.click();
		
		
		List<WebElement> elements = driver.findElements(chiffonDress);
		
		for(int i =0  ;i < elements.size() ; i++)
		{
				
			String value = elements.get(i).getText();
			
			System.out.println(value);
			
			
			if(value.equals("Printed Chiffon Dress"))
			{
				
                Actions a  = new Actions(driver); 
				a.moveToElement(elements.get(i)) ; 
				a.build().perform();
				
				WebElement addToCart = wait.until(ExpectedConditions
							.visibilityOfElementLocated(By.xpath("//*[@data-id-product='"+(i+1)+"']/span")));
				 addToCart.click();

				 WebElement proceedToCheckout = wait.until(ExpectedConditions
							.visibilityOfElementLocated(proceedCheckout));
				 proceedToCheckout.click();
				 flag =1 ;
					System.out.println("women Dress : rinted Chiffon added to cart sucessfully" );
			}
		
			
		}
		
		
		
		if(flag!=1)
		{
			WebElement goToCart = wait.until(ExpectedConditions
					.visibilityOfElementLocated(cart));
			goToCart.click();
			throw new Exception("Printed Chiffon Dress was not found");
			
		}
		
	


	}
	
	
	

}
