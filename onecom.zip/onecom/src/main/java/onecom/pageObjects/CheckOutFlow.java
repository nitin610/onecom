package onecom.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class CheckOutFlow extends BasePage {

	private By reduceQuantity = By.xpath("//*[@class='icon-minus']");
	private By proceedCheckout = By.xpath("//*[@class='button btn btn-default standard-checkout button-medium']");
	private By createEmail = By.xpath("//*[@id='email_create']");
	private By createAcc = By.xpath("//*[@id='SubmitCreate']");
	private By fName = By.xpath("//*[@id='customer_firstname']");
	private By lName = By.xpath("//*[@id='customer_lastname']");
	private By passw = By.xpath("//*[@id='passwd']");
	private By add = By.xpath("//*[@id='address1']");
	private By cityAdd = By.xpath("//*[@id='city']");
	private By zipCodeAdd = By.xpath("//*[@id='postcode']");
	private By mobNoAdd = By.xpath("//*[@id='phone_mobile']");
	private By reg = By.xpath("//*[@id='submitAccount']");
	private By proceedCheckoutAdd = By.xpath("//*[@class='button btn btn-default button-medium']");
	private By shipTerms = By.xpath("//*[@id='cgv']");
	private By payment = By.xpath("//*[@class='bankwire']");
	private By confirmOrd = By.xpath("//*[contains(text(),'I confirm my order')]");
	private By amount = By.xpath("//*[@class='price']");
	private WebDriver driver;

	public CheckOutFlow(WebDriver driver) {
		super(driver);
		this.driver = driver;
		// TODO Auto-generated constructor stub
	}

	public void checkoutSummaryTab() throws InterruptedException {
		// Reduce Quantity in Order Summary Tab

		WebElement reduceQuan = wait.until(ExpectedConditions.visibilityOfElementLocated(reduceQuantity));
		reduceQuan.click();

		WebElement procCheckout = wait.until(ExpectedConditions.visibilityOfElementLocated(proceedCheckout));
		procCheckout.click();

		System.out.println("Quanity Reduced by 1 in Summary Tab");

	}

	public void signOnTab() throws InterruptedException {

		// create account with details

		WebElement email = wait.until(ExpectedConditions.visibilityOfElementLocated(createEmail));
		email.sendKeys("nalety2@jadtys.com");

		WebElement createAccount = wait.until(ExpectedConditions.visibilityOfElementLocated(createAcc));
		createAccount.click();

		WebElement firstName = wait.until(ExpectedConditions.visibilityOfElementLocated(fName));
		firstName.sendKeys("Nitin");

		WebElement lastName = driver.findElement(lName);
		lastName.sendKeys("Alety");

		WebElement password = driver.findElement(passw);
		password.sendKeys("Nitin");

		WebElement address = driver.findElement(add);
		address.sendKeys("Pune");

		WebElement city = driver.findElement(cityAdd);
		city.sendKeys("Pune");

		Select state = new Select(driver.findElement(By.name("id_state")));
		state.selectByValue("5");

		WebElement ZipCode = driver.findElement(zipCodeAdd);
		ZipCode.sendKeys("00001");

		WebElement mobNo = driver.findElement(mobNoAdd);
		mobNo.sendKeys("1234567891");

		WebElement register = driver.findElement(reg);
		register.click();

		System.out.println("New Account created:");

	}

	public void addressTab() {

		WebElement add = driver.findElement(proceedCheckoutAdd);
		add.click();

		System.out.println("Address Tab ");

	}

	public void shippingTab() {

		WebElement checkBox = driver.findElement(shipTerms);
		checkBox.click();

		WebElement procCheckout = wait.until(ExpectedConditions.visibilityOfElementLocated(proceedCheckout));
		procCheckout.click();

		System.out.println("Shipping Tab ");

	}

	public String paymentTab() {

		WebElement paymentWire = driver.findElement(payment);
		paymentWire.click();

		WebElement confirmOrder = driver.findElement(confirmOrd);
		confirmOrder.click();

		WebElement orderAmount = driver.findElement(amount);
		orderAmount.getText();

		System.out.println("Payment Tab");

		return orderAmount.getText();

	}

}
