package onecom.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class EveningDress extends BasePage {

	private WebDriver driver;
	private By dress = By.xpath("(//*[@title='Dresses'])[2]");
	private By evenDress = By.xpath("(//*[@title='Evening Dresses'])[2]");
	private By printedDress = By.xpath("//*[@title='Printed Dress']");
	private By addCart = By.xpath("//*[contains(text(),'Add to cart')]");
	private By contShopping = By.xpath("//*[@class='continue btn btn-default button exclusive-medium']");
	private By quantity = By.xpath("//*[@id='quantity_wanted']");
	private By pinkCol = By.xpath("//*[@CLASS='color_pick']");

	public EveningDress(WebDriver driver) {
		super(driver);
		this.driver = driver;
		// TODO Auto-generated constructor stub
	}

	public void eveningDress() throws InterruptedException {

		Thread.sleep(5000);

		Actions a = new Actions(driver);
		a.moveToElement(driver.findElement(dress));
		a.build().perform();

		WebElement eveningDress = driver.findElement(evenDress);
		eveningDress.click();

		WebElement printedDres = driver.findElement(printedDress);
		printedDres.click();

		WebElement quantityNo = driver.findElement(quantity);
		quantityNo.clear();
		quantityNo.sendKeys("2");

		WebElement colorPink = driver.findElement(pinkCol);
		colorPink.click();

		Select drpCountry = new Select(driver.findElement(By.name("group_1")));
		drpCountry.selectByVisibleText("L");

		WebElement addToCart = wait.until(ExpectedConditions.visibilityOfElementLocated(addCart));
		addToCart.click();

		WebElement continueShopping = wait.until(ExpectedConditions.visibilityOfElementLocated(contShopping));
		continueShopping.click();

		System.out.println("Evening Dress : Printed Dress added to cart with Quantity: 2, Size: L, Color: Pink");
	}
}
