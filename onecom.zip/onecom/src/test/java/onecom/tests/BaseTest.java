package onecom.tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.FirefoxDriverManager;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTest {
	private WebDriver driver;
	
	public WebDriver getWebdriver(String browser) {
		
		if(browser.equals("chrome")) {

				WebDriverManager.chromedriver().setup();

				driver = new ChromeDriver();
			}
		else  if (browser.equals("firefox")) {

			WebDriverManager.firefoxdriver().setup();

			driver = (WebDriver) new FirefoxDriverManager();
		}
		return driver;	
	}

}
