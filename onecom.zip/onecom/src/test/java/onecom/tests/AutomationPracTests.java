package onecom.tests;



import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import onecom.pageObjects.CheckOutFlow;
import onecom.pageObjects.EveningDress;
import onecom.pageObjects.OrderHistory;
import onecom.pageObjects.WomenDresses;

public class AutomationPracTests extends BaseTest{
private WebDriver driver;

	
	
  @Test
  public void chatWithClients() throws Exception {
	  
	  // Evening Dress added to card
	  EveningDress eveDress = new EveningDress(driver);
      eveDress.eveningDress();
	  
      //Women Dress added to cart
	  WomenDresses woman  = new WomenDresses(driver);
	  woman.womanDress();
	  
	  //checkOut flow
	  CheckOutFlow sumCart   = new CheckOutFlow(driver);
	  //Reduce Quantity
	  sumCart.checkoutSummaryTab();
	  
	  //Create Account
	  sumCart.signOnTab();
	  
	  //Address Tab
	  sumCart.addressTab();
	  
	  //Shipping Tab
	  sumCart.shippingTab();
	  String orderAmount = sumCart.paymentTab();
	  
	  //Order History
	  OrderHistory ordHistory  = new OrderHistory(driver);
	  String OderHistoryAmount = ordHistory.order();
	  
	  //Compare Amount from Payment Summary Tab and Order History
	  Assert.assertEquals(orderAmount, OderHistoryAmount);
	  
  }
  @BeforeClass
  public void beforeClass() {
	  driver= getWebdriver("chrome");
	  driver.navigate().to("http://automationpractice.com/");
	  driver.manage().window().maximize();
 
  }

  @AfterClass
  public void afterClass() {
	  if(driver!=null) {
		  driver.quit();
	  }
	 
  }

}
